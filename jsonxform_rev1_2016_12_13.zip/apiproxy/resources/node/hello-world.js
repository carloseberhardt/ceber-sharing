var http = require('http')
var fs = require('fs')

var svr = http.createServer(function(req, resp) {
    fs.readFile('mock.json', function(error, mock) {
        if (error) {
            response.writeHead(500)
            response.end('Something is broken. Probably the code.')
        } else {
            resp.writeHead(200, {'Content-Type': 'application/json'})
            resp.end(mock, 'utf-8')
        }
    })
})

svr.listen(9000, function() {
    console.log('Node HTTP server is listening')
})