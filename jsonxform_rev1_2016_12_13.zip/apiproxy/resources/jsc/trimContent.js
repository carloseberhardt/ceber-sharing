var r = JSON.parse(response.content)
var newdeal = []

for (var i = 0, len = r.deal.length; i < len; i++) {
  newdeal.push({
    "id": r.deal[i].dealId,
    "merchant": r.deal[i].merchantName,
    "imageURL": r.deal[i].imageURL,
    "imageText": r.deal[i].imageText,
    "dealAmount":r.deal[i].dealedAmount,
    "label": r.deal[i].smallDescription,
    "percentageDeal": r.deal[i].isPercentageDeal
  })
}

r.deal = newdeal

response.content = JSON.stringify(r)

